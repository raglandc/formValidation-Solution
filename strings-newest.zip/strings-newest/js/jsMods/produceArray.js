export default function displayArray(arrayItem, displayItem){
    displayItem.innerHtml = arrayItem;
}